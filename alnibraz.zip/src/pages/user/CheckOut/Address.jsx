import React from 'react'
const Address = () => {
    return (
        <div className="border border-gray-200 rounded-md p-4 max-w-md bg-white shadow-sm">
            <div className="flex justify-between items-center mb-2">
                <div className="inline-block bg-teal-100 text-teal-900 text-sm font-semibold px-3 py-1 rounded">
                    Home
                </div>
                <button className="text-sm text-blue-600 hover:underline font-medium cursor-pointer">
                    Manage Address
                </button>
            </div>

            <div className="font-semibold text-base">
                Jonathan Jacob <span className="text-black font-normal">+9715035241</span>
            </div>
            <div className="text-gray-500 text-sm">
                Red Tape Building Nahda road, Sharjah, UAE – <span className="font-semibold">000000</span>
            </div>
        </div>


    )
}
export default Address