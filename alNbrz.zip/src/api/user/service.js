import API from "../httpService";
import { CATEGORY_LIST,BRAND_LIST,PRODUCT_LIST } from "./endpoint";


export const fetchCategoryList = async () => {
  const response = await API.get(CATEGORY_LIST);
  return response?.data?.data ?? [];
};
export const fetchBrandList = async () =>{
  const response = await API.get(BRAND_LIST);
   return response?.data?.data ?? [];
}

export const fetchProducts = async ({ pageParam = 1 }) => {
  const response = await API.get(PRODUCT_LIST, {
    headers: {
      page: pageParam,
      pageSize: 10,
    },
  });

  // Important: API should return array (or { data: [] })
  return {
    data: response?.data?.data ?? [],
  };
};

export const fetchSingleProduct = async (productId) => {
  const response = await API.get(PRODUCT_LIST, {
    headers: {
      page: 1,
      pageSize: 10,
      productID: productId,
    },
  });

  return response?.data?.data?.[0] ?? {};
};