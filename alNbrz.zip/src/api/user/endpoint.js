// User
export const CATEGORY_LIST = "getCategoryMaster";
export const BRAND_LIST = "getBrandMaster"
export const PRODUCT_LIST = "getProductMaster"

