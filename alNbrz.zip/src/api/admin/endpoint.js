// dashboard
export const ADMIN_LOGIN = "oauth";
// export const USER_LOGIN = "6661/login";
// export const TODAY_INSIGHT = "6662/TodayInsights";
// export const TODAY_INSIGHT_GAPH = "6662/RevenueVsProfitVsExpense";
// export const TOTAL_REVENUE = "6662/TotalRevenue";
