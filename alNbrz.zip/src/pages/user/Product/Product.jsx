import React, { useEffect,useState } from 'react'
import ProductDetails from './ProductDetails'
import ImageSection from './ImageSection'
import RecentSearch from './RecentSearch'
import { useSingleProduct } from "../../../api/user/hooks"
import { useParams } from "react-router-dom";
const Product = () => {
  const { id } = useParams()
  const { data } = useSingleProduct(id);
  const [selectedVariant, setSelectedVariant] = useState(null);
  useEffect(() => {
    if (data) {
      console.log("Product Data:", data);
    }
  }, [data]);
  useEffect(() => {
    if (data?.variants?.length > 0) {
      setSelectedVariant(data.variants[0]); // Set default
    }
  }, [data]);
  return (
    <div className='p-5 xl:p-16'>
      <div className='grid grid-cols-1  md:grid-cols-2 gap-6'>
        <div>
          <ImageSection images={selectedVariant?.images || []}/>
        </div>
        <div>
          <ProductDetails details={data} selectedVariant={selectedVariant} 
                          setSelectedVariant={setSelectedVariant}/>
        </div>
      </div>
      <RecentSearch />
    </div>
  )
}

export default Product