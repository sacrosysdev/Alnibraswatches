import React, { useRef, useCallback } from 'react'
import ShopCard from './ShopCard'
import { useProductList } from '../../../api/user/hooks'
import {  FadeLoader  } from "react-spinners"

const ProductListing = () => {
  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    isLoading
  } = useProductList();
  const observer = useRef();
  const loadMoreRef = useCallback(
    (node) => {
      if (observer.current) observer.current.disconnect();
      observer.current = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting && hasNextPage) {
          fetchNextPage();
        }
      });
      if (node) observer.current.observe(node);
    },
    [fetchNextPage, hasNextPage]
  );
  return (
    <div>
      {isLoading ?  <div className='flex justify-center'>
           <FadeLoader color="#005C53"/>
          </div> : <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2 md:gap-4">
        {data?.pages.map((group, groupIndex) =>
          group.data.map((item, index) => {
            const isLast =
              groupIndex === data.pages.length - 1 &&
              index === group.data.length - 1;
            return isLast ? (
              <div ref={loadMoreRef} key={item.productId}>
                <ShopCard
                  id={item.productId}
                  image={item.imageUrl}
                  title={item.productName}
                  brand={item.brandName}
                  price={item.price}
                />
              </div>
            ) : (
              <ShopCard
                key={item.productId}
                id={item.productId}
                image={item.imageUrl}
                title={item.productName}
                brand={item.brandName}
                price={item.price}
              />
            );
          })

        )}
      </div>}
      {isFetchingNextPage && (
        <div className='flex justify-center'>
           <FadeLoader color="#005C53"/>
          </div>
      )}
    </div>
  )
}

export default ProductListing