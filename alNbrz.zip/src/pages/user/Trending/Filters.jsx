import React from 'react'




  export const StarRating = ({ rating }) => (
  
      
  
  );
  