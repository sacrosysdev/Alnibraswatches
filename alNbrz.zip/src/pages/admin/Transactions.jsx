import React from "react";

const Transactions = () => {
  return <div></div>;
};

export default Transactions;
