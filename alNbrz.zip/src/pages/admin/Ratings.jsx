import React from "react";

const Ratings = () => {
  return <div></div>;
};

export default Ratings;
