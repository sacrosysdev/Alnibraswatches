import React from "react";

const AddProduct = () => {
  return <div></div>;
};

export default AddProduct;
