import React from "react";

const Coupons = () => {
  return <div></div>;
};

export default Coupons;
