import React from "react";

const Brands = () => {
  return <div></div>;
};

export default Brands;
