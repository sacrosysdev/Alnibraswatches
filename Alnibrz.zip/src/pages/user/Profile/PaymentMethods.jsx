import React from 'react'

const PaymentMethods = () => {
  return (
    <div>PaymentMethods</div>
  )
}

export default PaymentMethods