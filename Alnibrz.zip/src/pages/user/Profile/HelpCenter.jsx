import React from 'react'

const HelpCenter = () => {
  return (
    <div>HelpCenter</div>
  )
}

export default HelpCenter