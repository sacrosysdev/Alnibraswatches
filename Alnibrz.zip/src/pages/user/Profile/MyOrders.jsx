import React from 'react'

const MyOrders = () => {
  return (
    <div>MyOrders</div>
  )
}

export default MyOrders