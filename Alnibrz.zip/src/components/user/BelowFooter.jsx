import React from 'react'

const BelowFooter = () => {
  return (
    <div>
        <h1 className='text-[#003F38] text-center py-2 bg-[#A3C4C1]'>© 2025 Gold E commerce  All rights reserved.</h1>
    </div>
  )
}

export default BelowFooter